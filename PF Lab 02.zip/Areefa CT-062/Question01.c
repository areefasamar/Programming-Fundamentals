#include<stdio.h>
int main()
{
	printf("\a\a\a\a\a");
	return 0;
}