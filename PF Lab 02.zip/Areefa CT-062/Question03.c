#include<stdio.h>
int main()
{
	printf("*\n\n*  *\n\n*  *  *\n\n*  *  *  *\n\n\n");
	printf(" *\n\n *\t*\n\n *\t*\t*\n\n *\t*\n\n *");
	return 0;
}
