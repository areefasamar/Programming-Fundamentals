#include<stdio.h>
int main(void)
{  
  printf("   *********\t\t   ***   \t\t  *  \t\t    *    \n   *\t   *\t\t *     *\t\t ***\t\t  *   *\n   *\t   *\t\t*       *\t\t*****\t\t *     *\n   *\t   *\t\t*       *\t\t  *  \t\t*       *\n   *\t   *\t\t*       *\t\t  *  \t       *\t *\n   *\t   *\t\t*       *\t\t  *  \t\t*       *\n   *\t   *\t\t*       *\t\t  *  \t\t *     *\n   *\t   *\t\t *     *\t\t  *  \t\t  *   *\n   *********\t\t   ***   \t\t  *  \t\t    *    \n"); 
 return 0;
}